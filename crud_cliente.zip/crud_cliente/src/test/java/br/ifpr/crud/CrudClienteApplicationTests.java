package br.ifpr.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
